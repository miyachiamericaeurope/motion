#ifndef _INCLUDE_WEBU_TEXT_H_
#define _INCLUDE_WEBU_TEXT_H_


void webu_text_badreq(struct webui_ctx *webui);
void webu_text_main(struct webui_ctx *webui);
void webu_text_status(struct webui_ctx *webui);
void webu_text_connection(struct webui_ctx *webui);
void webu_text_list(struct webui_ctx *webui);
void webu_text_get_query(struct webui_ctx *webui);

#endif
